#!/bin/bash

########################################
############# CSCI 2951-O ##############
########################################

# Update this file with instructions on how to compile your code
javac -classpath /local/projects/cplex/CPLEX_Studio2211/cpoptimizer/lib/ILOG.CP.jar ./src/solver/cp/*.java
